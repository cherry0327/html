#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;
#include<fstream>


//login
class Login														//class to store data in the file with object
{
	char username[20], password[20];
	int id;
public:

	void data()													//to get data from user
	{
		cout << "Enter the id: ";
		cin >> id;
		cout << "Enter the login name: ";
		cin >> username;
		cout << "Enter the password: ";
		cin >> password;
	}

	void UpdatePass()
	{
		char pass[20];
		cout << "Enter the old password: ";
		cin >> pass;
		if (strcmp(pass, password) == 0)
		{
			cout << "Enter new password: ";
			cin >> password;
			cout << "Successfully update the password." << endl;
		}
		else
		{
			cout << "Wrong password." << endl;
		}
	}

	char * getName()
	{
		return username;
	}

	char * getPass()
	{
		return password;
	}

	int getId()
	{
		return id;
	}
};

//product
class ProductDetails											//class to store data of products in file 
{
	int prdtid, stock;
	char manf[10], exp[10];
	char prdtname[20];
	float price;
public:
	void setData()											//getting data to store product details
	{
		cout << "Enter the product id: ";
		cin >> prdtid;
		cout << "Enter the product name: ";
		getchar();
		cin.getline(prdtname, 20);
		cout << "Price: ";
		cin >> price;
		cout << "Manufacturing date[DD/MM/YY]: ";
		cin >> manf;
		cout << "Expiry date[DD/MM/YY]: ";
		cin >> exp;
		cout << "Number of stock: ";
		cin >> stock;
	}

	int getPrdtid()
	{
		return prdtid;
	}

	char * getPrdtname()
	{
		return prdtname;
	}

	float getPrice()
	{
		return price;
	}

	int getStock()
	{
		return stock;
	}

	void setStock(int n)
	{
		stock = stock - n;
	}

	void display()									//displays product details
	{
		cout << prdtid << "\t" << prdtname << "\t" << price << "\t" << manf << "\t" << exp << "\t" << stock << endl;
	}
};

//category
class Category															// class to do operation using data stored in the file
{
	int id;
	char name[20];
public:

	void setCat()												//function get category details
	{
		cout << "Enter the category id: ";
		cin >> id;
		cout << "Enter the category name: ";
		cin >> name;
	}

	void AddCat()														//to add category
	{
		setCat();
		fstream file("Category.dat", ios::binary | ios::app);
		file.write((char *)this, sizeof(*this));
		file.close();
	}

	void RemCat()														//to remove category
	{
		int iid= 0, flag = 0;											
		cout << "Enter the category id: ";
		cin >> id;
		fstream file("Category.dat", ios::binary | ios::in);			//to get data from file
		fstream file1("temp.dat", ios::binary | ios::out);				//temporary file to write the required data
		while (!file.eof())
		{
			file.read((char *)this, sizeof(*this));
			if (iid == id)
			{
				flag = 1;
				continue;
			}
			file1.write((char *)this, sizeof(*this));
		}
		if (flag != 1)
		{
			cout << "Category id not found" << endl;
			return;
		}
		file.close();
		file1.close();
		remove("Category.dat");										//deleting the old category file
		rename("temp.dat", "Category.dat");							//rename the temporary file
		cout << "Successfully removed the category." << endl;
	}

	char * getCatByname(char catname[])							//to search category by name
	{
		ifstream file("Category.dat", ios::binary);
		while (!file.eof())
		{
			file.read((char *)this, sizeof(*this));
			if (strcmp(name, catname) == 0)
			{
				char catname[30];
				strcpy(catname, name);
				strcat(catname, ".DAT");
				return catname;							//returns file name of category
			}
		}
		cout << "Unavailable category name" << endl;
		return "error";
	}

	char * getCatByid(int catid)								//to search category by id
	{
		ifstream file("Category.dat", ios::binary);
		while (!file.eof())
		{
			file.read((char *)this, sizeof(*this));
			if (id == catid)
			{
				char catname[30];
				strcpy(catname, name);
				strcat(catname, ".DAT");
				return catname;							//returns file name of category
			}
		}
		cout << "Unavailable category id" << endl;
		return "error";
	}

	void Display()
	{
		cout << id << "\t" << name << endl;
	}
};

//administrator
class Administrator														//class to be operated and login for administrator
{
public:
	void signIn()
	{
		char user[20], pass[20];
		int n = 0;
		Login log;
		/*ofstream file1("Administrator.dat",ios::binary);
		log.data();
		file1.write((char *)&log,sizeof(log));*/
		ifstream file("Administrator.dat", ios::binary);					//file stores administrator username and password
		file.read((char *)&log, sizeof(log));
	admin:
		cout << "Enter the login name: ";
		cin >> user;
		cout << "Enter the password: ";
		cin >> pass;
		if (strcmp(user, log.getName()) == 0 && strcmp(pass, log.getPass()) == 0)
		{
			cout << "Login successful\n" << endl;
			this->navigation();
			return;
		}
		else
			cout << "Login failed\n" << endl;
		n++;
		if (n == 3)
			return;
		else
		{
			cout << endl;
			goto admin;
		}
	}

	void navigation()
	{
		int ch;
	admin:
		cout << "1.Add Employee\t2.Add Product\t3.Remove Employee\t4.Remove Product\t5.Add Category\t6.Remove Category\t7.Back to main menu" << endl;
		cout << "Enter your choice: ";
		cin >> ch;
		switch (ch)
		{
		case 1:Addemp();
			break;
		case 2:AddProduct();
			break;
		case 3:RemoveEmp();
			break;
		case 4:RemoveProduct();
			break;
		case 5:
		{
			Category cat;
			cat.AddCat();
			cout << "Sucessfully added the category." << endl;
		}
			break;
		case 6:
		{
			Category cat;
			cat.RemCat();
		}
			break;
		case 7:return;
		default:cout << "Invalid choice" << endl;
		}
		cout << endl;
		goto admin;
	}

	void Addemp()												//function to add employee
	{
		Login log;
		log.data();
		fstream file("Employee.dat", ios::binary | ios::app);	//file of employee username and password
		file.write((char *)&log, sizeof(log));
		file.close();
		cout << "Successfully added the employee." << endl;
	}

	void RemoveEmp()											//function to remove employee
	{
		int flag = 0, id;
		Login log;
		char name[20];
		cout << "Enter the employee name: ";
		cin >> name;
		cout << "Enter the employee id: ";
		cin >> id;
		fstream file("Employee.dat", ios::binary | ios::in);
		fstream file1("temp.dat", ios::binary | ios::out);		//temporary file
		while (!file.eof())
		{
			file.read((char *)&log, sizeof(log));
			if (strcmp(name, log.getName()) == 0 && id == log.getId())
			{
				flag = 1;
				continue;
			}
			file1.write((char *)&log, sizeof(log));
		}
		if (flag != 1)
		{
			cout << "Employee name not found" << endl;
			return;
		}
		file.close();
		file1.close();
		remove("Employee.dat");									//removing the old file
		rename("temp.dat", "Employee.dat");						//renaming the temporary file
		cout << "Successfully removed the employee." << endl;
	}
	void AddProduct()											//function to add product
	{
		int ch, id;
		Category cat;
		char name[20], catname[20];
	cat:
		cout << "1.Category name\t2.Category id" << endl;
		cin >> ch;
		switch (ch)
		{
		case 1:												//searching by name
		{
			cout << "Enter the category name: ";
			cin >> name;
			strcpy(catname, cat.getCatByname(name));
			if (strcmp(catname, "error") == 0)
			{
				cout << "Invalid Category id" << endl;
				goto cat;
			}
		}
		break;
		case 2:												//searching by id
		{
			cout << "Enter the category id: ";
			cin >> id;
			strcpy(catname, cat.getCatByid(id));
			if (strcmp(catname, "error") == 0)
			{
				cout << "Invalid Category id" << endl;
				goto cat;
			}
		}
		break;
		default:
		{
			cout << "Invalid choice" << endl;
			return;
		}
		}
		cout << "Category name: " << catname << endl;
		ProductDetails pd;
		pd.setData();
		fstream file(catname, ios::binary | ios::app);		//category name is the file name return from class category
		file.write((char *)&pd, sizeof(pd));
		file.close();
		cout << "Successfully added the product." << endl;
	}

	void RemoveProduct()									//funciton to remove product
	{
		int ch, id, flag = 0;
		char prdtname[20];
		Category cat;
		char name[20], catname[20];
	cat:
		cout << "1.Category name\t2.Category id" << endl;
		cout << "Enter your choice: ";
		cin >> ch;
		switch (ch)
		{
		case 1:
		{
			cout << "Enter the category name: ";
			cin >> name;
			strcpy(catname, cat.getCatByname(name));
			if (strcmp(catname, "error") == 0)
			{
				cout << "Invalid Category id" << endl;
				goto cat;
			}
		}
		break;
		case 2:
		{
			cout << "Enter the category id: ";
			cin >> id;
			strcpy(catname, cat.getCatByid(id));
			if (strcmp(catname, "error") == 0)
			{
				cout << "Invalid Category id" << endl;
				goto cat;
			}
		}
		break;
		default:cout << "Invalid choice" << endl;
		}
		ProductDetails pd;
		cout << "Enter the product name: ";
		cin >> prdtname;
		fstream file(catname, ios::binary | ios::in);		//category name is the file name return from class category
		fstream file1("temp.dat", ios::binary | ios::out);
		while (!file.eof())
		{
			file.read((char *)&pd, sizeof(pd));
			if (strcmp(prdtname, pd.getPrdtname()) == 0)
			{
				flag = 1;
				continue;
			}
			file1.write((char *)&pd, sizeof(pd));
		}
		if (flag != 1)
		{
			cout << "Product name not found" << endl;
			return;
		}
		file.close();
		file1.close();
		remove(catname);
		rename("temp.dat", catname);
		cout << "Successfully removed the product." << endl;
	}
};

class CustomerDetails									//class to store customer details
{
	char name[20];
	int cardno, points;
public:

	CustomerDetails()
	{
		cardno = NULL;
	}

	void setCust()
	{
		cout << "Enter the customer name: ";
		cin >> name;
		cout << "Enter the card number: ";
		cin >> cardno;
		points = 0;
	}

	char * getName()
	{
		return name;
	}

	int getCardno()
	{
		return cardno;
	}

	int getPoints()
	{
		return points;
	}

	void setPoint(int p)
	{
		points = p;
	}

	void Addnew()												//Function to Add new Customer
	{
		this->setCust();
		ofstream customer("Customer.dat", ios::binary | ios::app);
		customer.write((char *)this, sizeof(*this));
		customer.close();
	}

	void CheckPoints()											//Function to check CustomerCard Points
	{
		int card;
		cout << "Enter the customer card number: ";
		cin >> card;
		ifstream customer("Customer.dat", ios::binary);
		while (!customer.eof())
		{
			customer.read((char *)this, sizeof(*this));
			if (card == cardno)
				goto here;
		}
		customer.close();
		cout << "Invalid card number" << endl;
		return;
	here:
		cout << "Customer name: " << name << endl;
		cout << "Points: " << points << endl;
		customer.close();
	}

	CustomerDetails getDetails(int card)										//Function to store Customer Card Details
	{
		CustomerDetails cd1;
		ifstream customer("Customer.dat", ios::binary);
		while (!customer.eof())
		{
			customer.read((char *)this, sizeof(*this));
			if (card == cardno)
				goto here;
		}
		cout << "Invalid card number" << endl;
		return cd1;
	here:
		return *this;
	}

	void Update(int cardno, int point)											//function to update check points
	{
		int offset;
		fstream customer("Customer.dat", ios::binary | ios::in);
		while (!customer.eof())
		{
			customer.read((char *)this, sizeof(*this));
			if (cardno == cardno)
			{
				offset = customer.tellg();
				offset = offset - sizeof(*this);
				break;
			}
		}
		customer.close();
		setPoint(point);
		customer.open("Customer.dat", ios::binary | ios::in | ios::ate | ios::out);
		customer.seekp(offset, ios::beg);
		customer.write((char *)this, sizeof(*this));
		customer.close();
	}
};

class Employee												//class to be operated by employee
{
	int billno;
	float amt;
	int dis_amt;
	int date;
public:
	void signIn()
	{
		char user[20], pass[20];
		Login log;
		int n = 0, ch;
		cout << "1.Login\t2.Update password\t3.Back to main menu" << endl;
		cout << "Enter your choice: ";
		cin >> ch;
		switch (ch)
		{
		case 1:
		{
			ifstream file("Employee.dat", ios::binary);
		emp:
			cout << "Enter the login name: ";
			cin >> user;
			cout << "Enter the password: ";
			cin >> pass;
			while (!file.eof())
			{
				file.read((char *)&log, sizeof(log));
				if (strcmp(user, log.getName()) == 0)
					break;
			}
			if (strcmp(user, log.getName()) == 0 && strcmp(pass, log.getPass()) == 0)
			{
				cout << "Login successful\n" << endl;
				this->navigation(log.getName());
				return;
			}
			else
				cout << "Login failed\n" << endl;
			n++;
			if (n == 3)
				return;
			goto emp;
		}
		break;

		case 2:
		{
			Login log;
			int offset, id;
			cout << "Enter the employee id: ";
			cin >> id;
			fstream employee("Employee.dat", ios::binary | ios::in);
			while (!employee.eof())
			{
				employee.read((char *)&log, sizeof(log));
				if (id == log.getId())
				{
					offset = employee.tellg();
					offset = offset - sizeof(log);
					break;
				}
			}
			employee.close();
			log.UpdatePass();
			employee.open("Employee.dat", ios::binary | ios::in | ios::ate | ios::out);
			employee.seekp(offset, ios::beg);
			employee.write((char *)&log, sizeof(log));
			employee.close();
		}
		break;
		case 3:return;
			break;
		default:cout << "Invalid choice" << endl;
		}

	}

	void navigation(char name[])									//Function to navigate for the Employee
	{
		int ch, ch1;
		CustomerDetails cf;
	emp:
		cout << "1.Bill\t2.Customer Card\t3.Back to main menu" << endl;
		cout << "Enter your choice: ";
		cin >> ch;
		switch (ch)
		{
		case 1:Billgen(name);
			break;
		case 2:
		{
			cout << "1.New customer\t2.Check points" << endl;
			cout << "Enter your choice: ";
			cin >> ch1;
			if (ch1 == 1)
			{
				cf.Addnew();
			}
			else if (ch1 == 2)
			{
				cf.CheckPoints();
			}
			else
				cout << "Invalid choice" << endl;
		}
		break;
		case 3:return;
			break;
		default:cout << "Invalid choice." << endl;
		}
		cout << endl;
		goto emp;
	}

	void Billgen(char name[])
	{
		int catid, prdtid, n = 0, ch, qty[100], i, flag = 0, card, point, offset;
		float cardoff = 0, offer;
		char catname[20];
		CustomerDetails cd;
		cout << "Enter the customer card number: ";
		cin >> card;
		cd = cd.getDetails(card);
		if (cd.getCardno() == NULL)
			return;
		cout << "Customer name: " << cd.getName() << endl;
		cout << "Points: " << cd.getPoints() << endl;
		point = cd.getPoints();
		if (point>100)
		{
			cardoff = (float)20 / 100;
			cd.Update(cd.getCardno(), point - 100);
		}
		amt = 0;
		Category cat;
		cout << "Enter the bill number: ";
		cin >> billno;
	addprdt:
	cat :
		cout << "Category Details:" << endl;
		fstream filec("Category.dat", ios::binary | ios::in);
		while (true)
		{
			filec.read((char *)&cat, sizeof(cat));
			if (filec.eof())
				break;
			cat.Display();
		}
		filec.close();
		cout << "Enter the category id: ";
		cin >> catid;
		strcpy(catname, cat.getCatByid(catid));
		if (strcmp(catname, "error") == 0)
		{
			cout << "Invalid Category id" << endl;
			goto cat;
		}
		ProductDetails pd1;
		cout << "Product Details:\n" << endl;
		fstream file1(catname, ios::binary | ios::in);
		while (true)
		{
			file1.read((char *)&pd1, sizeof(pd1));
			if (file1.eof())
				break;
			pd1.display();
		}
		cout << "Enter the product id: ";
		cin >> prdtid;
		ProductDetails pd[100];
		fstream file(catname, ios::binary | ios::in);		//category name is the file name return from class category
		while (!file.eof())
		{
			file.read((char *)&pd[n], sizeof(pd[n]));
			if (prdtid == pd[n].getPrdtid())
			{
				offset = file.tellg();
				offset = offset - sizeof(pd[n]);
				flag = 1;
				break;
			}
		}
		if (flag != 1)
			cout << "Invalid product id" << endl;
		else
		{
		stock:
			cout << "Enter the quantity: ";
			cin >> qty[n];
			if (qty[n] > pd[n].getStock())
			{
				cout << "Out of stock" << endl;
				goto stock;
			}
			else
			{
				file.close();
				pd[n].setStock(qty[n]);
				file.open(catname, ios::binary | ios::in | ios::ate | ios::out);
				file.seekp(offset, ios::beg);
				file.write((char *)&pd[n], sizeof(pd[n]));
			}
			cout << "Product name: " << pd[n].getPrdtname() << endl;
			cout << "Price: " << pd[n].getPrice() << endl;
			cout << "Total: " << qty[n] * pd[n].getPrice();
			amt = amt + (pd[n].getPrice()*qty[n]);
			cout << "\tGrand Total: " << amt << endl << endl;
		}
		cout << "1.Add product\t2.Generate Bill" << endl;
		cout << "Enter your choice: ";
		cin >> ch;
		switch (ch)
		{
		case 1:
		{
			n++;
			flag = 0;
			goto addprdt;
		}
		break;
		case 2:
		{
			offer = (amt - (amt*cardoff));
			ofstream bill("Bill.txt", ios::app);
			cout << "\nBill no.:" << billno << "\t\t\t\t\t" << "Employee name:" << name << endl;
			cout << "Card no.:" << cd.getCardno() << "\t\t\t\t\t" << "Customer name:" << cd.getName() << endl;
			cout << "------------------------------------------------------------------------" << endl;
			cout << "\tProduct ID" << "\tProduct Name" << "\tQuantity" << "\tPrice" << endl;
			for (i = 0; i <= n; i++)
			{
				cout << "\t" << pd[i].getPrdtid() << "\t\t" << pd[i].getPrdtname() << "\t\t" << qty[i] << "\t\t" << qty[i] * pd[i].getPrice() << endl;
			}
			cout << "------------------------------------------------------------------------" << endl;
			cout << "Grand total:" << amt << "\t\t\t\t\t" << "Offered Price:" << (amt - (amt*cardoff)) << endl << endl;

			bill << "\nBill no.:" << billno << "\t\t\t\t\t" << "Employee name:" << name << endl;
			bill << "Card no.:" << cd.getCardno() << "\t\t\t\t\t" << "Customer name:" << cd.getName() << endl;
			bill << "------------------------------------------------------------------------" << endl;
			bill << "\tProduct ID" << "\tProduct Name" << "\tQuantity" << "\tPrice" << endl;
			for (i = 0; i <= n; i++)
			{
				bill << "\t" << pd[i].getPrdtid() << "\t\t" << pd[i].getPrdtname() << "\t\t" << qty[i] << "\t\t" << qty[i] * pd[i].getPrice() << endl;
			}
			bill << "------------------------------------------------------------------------" << endl;
			bill << "Grand total:" << amt << "\t\t\t\t\t" << "Offered Price:" << offer << endl << endl;
			bill << "************************************************************************\n" << endl;

			file.close();

			if (offer>1000)
			{
				int up = (offer / 1000);
				cd.Update(cd.getCardno(), up * 10);
			}
		}
		break;
		}
	}
};

class Customer										//Class for Customer Function 
{
	Category cat;
	ProductDetails pd;
public:
	void Display()										//Function to display Data based on Category
	{
		int ch;
		char catname[20], temp[20], temp1[100];
		cout << "Category Details:" << endl;
		fstream filec("Category.dat", ios::binary | ios::in);
		while (true)
		{
			filec.read((char *)&cat, sizeof(cat));
			if (filec.eof())
				break;
			cat.Display();
		}
		cout << "Enter the category name: ";
		cin >> temp;
		strcpy(catname, cat.getCatByname(temp));
		if (strcmp(catname, "error") == 0)
		{
			return;
		}
		cout << "Category name: " << catname << endl;
		fstream file(catname, ios::binary | ios::in);
		while (true)
		{
			file.read((char *)&pd, sizeof(pd));
			if (file.eof())
				break;
			pd.display();
		}
		cout << "Press any key to main menu" << endl;
		getchar();
		getchar();
	}

};

int main()
{
	int ch, n = 0;
here:
	system("CLS");
	cout << "1.Administrator\n2.Employee\n3.Customer\n4.Exit" << endl;
	cout << "Enter your choice: ";
	cin >> ch;
	switch (ch)
	{
	case 1:Administrator a;
		a.signIn();
		n = 0;
		break;
	case 2:Employee e;
		e.signIn();
		n = 0;
		break;
	case 3:Customer c;
		c.Display();
		n = 0;
		break;
	case 4:exit(0);
		break;
	default:cout << "Invalid choice" << endl;
	}
	n++;
	if (n == 2)
		exit(0);
	goto here;
}